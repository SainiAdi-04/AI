% Facts
warm.
raining.
sunny.
pleasant.

% Rules
enjoy :- sunny, warm.
strawberry_picking :- warm, pleasant.
not_strawberry_picking :- raining.
wet :- raining.
